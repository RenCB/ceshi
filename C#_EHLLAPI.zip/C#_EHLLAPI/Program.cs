﻿//Hi 2024
using C__EHLLAPI.PublicClasses;
using System.Text;

class EHLLProgram
{
    static void Main()

    {

        Console.WriteLine("Hello EHLLAPI Program from here!");

        

        UInt32 ReturnCode;
        RC_CODE RtMessage;

        //连接测试
        ReturnCode = Funcs.ConnectToPS("A");
        RtMessage = (RC_CODE)ReturnCode;

        //断开测试
        //ReturnCode = Funcs.DisonnectFromPS();
        //RtMessage = (RC_CODE)ReturnCode;

        //发送按键测试
        //ReturnCode = Funcs.SendKeystrokes("GAIO !");
        //RtMessage = (RC_CODE)ReturnCode;

        //获取坐标测试 613
        //ReturnCode = Funcs.QueryCursor(out cp);
        //RtMessage = (RC_CODE)ReturnCode;

        //设置坐标
        //ReturnCode = Funcs.SetCursor(666);
        //RtMessage = (RC_CODE)ReturnCode;

        //拷贝字符串到输入栏
        //ReturnCode = Funcs.CopyStrToField("Ni Hao", 613);
        //RtMessage = (RC_CODE)ReturnCode;


        //UInt32 len;
        // UInt32 rc =  Funcs.SetSessionParameters(out len);
        //Console.WriteLine($"长度:{len},返回值:{rc}");

        //测试设置会话参数
        //UInt32 llen;
        //UInt32 rc =  Funcs.SetSessionParameters(out llen);

        //测试搜索目标字符
        //Console.WriteLine($"连接{RtMessage}");
        //Console.WriteLine(Funcs.SearchPS("DSP67", 613));

        //测试锁定键盘输入
        //Console.WriteLine(Funcs.LockKeyBoard());

        //测试释放键盘
        //Console.WriteLine(Funcs.ReleaseKeyBoard());

        //测试等待屏幕
        //Console.WriteLine(Funcs.WaitScreen());

        if (ReturnCode == 0)
        {


            //UInt32 llen;
            //UInt32 rc =  Funcs.SetSessionParameters(out llen);

            // Funcs.ResetSystem();

            UInt32 len;
            StringBuilder data;
            Funcs.CopyFieldStrFromPS(out data,out len,755);



            Console.WriteLine(data.ToString());
            Console.WriteLine($"获取的字符长度:{len}");

            //UInt32 p;
           // Funcs.QueryCursor(out p);
            //Console.WriteLine(p); //755 //1216
        }


    }
}
