﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C__EHLLAPI.PublicClasses
{
    enum RC_CODE:UInt32

    { 

        操作成功 = 0,
        操作失败 = 1,
        EHLLAPI接受的参数有误 = 2,
        会话忙碌或等待超时 = 4,
        会话锁定或键盘锁定 = 5,
        操作完成但数据被截断 = 6,
        坐标异常 = 7,
        遭遇系统错误 = 9,
        正在执行其他系统功能 = 11,
        未格式化会话或未找到字段或未找到目标字符 = 24,
        字段上字符长度为0 = 28
        
    }

}
