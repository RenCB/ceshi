﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C__EHLLAPI.PublicClasses
{
 
    
    enum Funcnum:UInt32

    {

        FN_CONNECT_PC = 1,
        FN_DISCONNECT_PC = 2,
        FN_SENDK_EYS = 3,
        FN_WAIT_SCREEN = 4,
        FN_SEARCH_PS = 6,
        FN_QUERY_CURSOR = 7,
        FN_SET_SESSION_PARAMETERS = 9,
        FN_LOCK_KB = 11,
        FN_RELEASE_KB = 12,
        FN_RESET_SYS = 21,
        FN_SET_CURSOR = 40,
        FN_COPY_TO_FIELD = 33,
        FN_COPY_FIELD_FROM_PS = 34,
        FN_FIND_FIELD_POSITION = 31,
        FN_FIND_FIELD_LENGTH = 32

    }

}
