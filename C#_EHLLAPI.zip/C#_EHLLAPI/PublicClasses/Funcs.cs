﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace C__EHLLAPI.PublicClasses
{
   
    public class HAPI
    {
        [DllImport(@"C:\Program Files (x86)\IBM\EHLLAPI\EHLAPI32.dll")]
        public static extern UInt32 hllapi(ref UInt32 FuncNum, StringBuilder Data, ref UInt32 Len, ref UInt32 Rc);
        
    }

    internal class Funcs
    {
        //Connect Presentation Space (1) 连接到会话

        public static UInt32 ConnectToPS(string sID)

        {

            StringBuilder d = new StringBuilder(4);
            d.Append(sID);
            UInt32 f = (UInt32)Funcnum.FN_CONNECT_PC;
            UInt32 l = 4;
            UInt32 rc = 0;
            HAPI.hllapi(ref f, d, ref l, ref rc);
            return rc;

        }

        //Disconnect Presentation Space (2) 从会话断开

        public static UInt32 DisonnectFromPS()

        {   

            StringBuilder d = new StringBuilder(0);
            UInt32 f = (UInt32)Funcnum.FN_DISCONNECT_PC;
            UInt32 l = 0;
            UInt32 rc = 0;
            HAPI.hllapi(ref f, d, ref l, ref rc);
            return rc;

        }

        //Send Key (3) 发送键盘按键和字符

        public static UInt32 SendKeystrokes(string keys)

        {

            StringBuilder d = new StringBuilder(keys.Length);
            d.Append(keys);
            UInt32 f = (UInt32)Funcnum.FN_SENDK_EYS;
            UInt32 l = (UInt32)keys.Length;
            UInt32 rc = 0;
            HAPI.hllapi(ref f, d, ref l, ref rc);
            return rc;

        }

        //Query Cursor Location (7) 获取坐标

        public static UInt32 QueryCursor(out UInt32 p)
        {
            StringBuilder d = new StringBuilder(0);
            UInt32 f = (UInt32)Funcnum.FN_QUERY_CURSOR;
            UInt32 l = 0;
            UInt32 rc = 0;
            HAPI.hllapi(ref f, d, ref l, ref rc);
            p = l;
            return rc;
        }

        //Set Cursor (40) 设置坐标

        public static UInt32 SetCursor(UInt32 cursor)
        {

            StringBuilder d = new StringBuilder(0);
            UInt32 f = (UInt32)Funcnum.FN_SET_CURSOR;
            UInt32 l = 0;
            UInt32 p = cursor;
            UInt32 rc = HAPI.hllapi(ref f, d, ref l, ref p);
            return rc;

        }

        //Copy String to Field (33) 将字符串拷贝到会话屏幕填写栏

        public static UInt32 CopyStrToField(string copyStr,UInt32 startPosition)

        {

            StringBuilder d = new StringBuilder(copyStr.Length);
            d.Append(copyStr);
            UInt32 f = (UInt32)Funcnum.FN_COPY_TO_FIELD;
            UInt32 l = (UInt32)copyStr.Length;
            UInt32 ps = startPosition;
            UInt32 rc = HAPI.hllapi(ref f, d, ref l, ref ps);
            return rc;

        }

        //Copy Field to String (34)
        
        public static UInt32 CopyFieldStrFromPS(out StringBuilder data, out UInt32 len, UInt32 p)

        {

            StringBuilder d = new StringBuilder(100);
            UInt32 f = 34;
            UInt32 l = 100;           
            UInt32 rc =  HAPI.hllapi(ref f, d, ref l, ref p);
            len = l;
            data = d;
            return rc;
  

        }

        //获取指定坐标所在field的下一个未保护的field坐标起点位置
        //文档里那个很难理解的符号代表空格，不要去研究什么你找不到答案，那就是空格符号😒
        public static UInt32 FindFieldPosition(out UInt32 len,  UInt32 p)
        {
            StringBuilder d = new StringBuilder(2);
            d.Append("T ");
            UInt32 f = (UInt32)Funcnum.FN_FIND_FIELD_POSITION;
            UInt32 l = 0;
            
            UInt32 rc = HAPI.hllapi(ref f, d, ref l, ref p);
            len = l;
            return rc;

        }

        //Find Field Length (32) 获取filed(字段 可以填写东西的区域）的长度

        public static UInt32 FindFieldLength(out UInt32 len, UInt32 p)
        {
            StringBuilder d = new StringBuilder(100);
            d.Append("T ");
            UInt32 f = (UInt32)Funcnum.FN_FIND_FIELD_LENGTH;
            UInt32 l = 0;
            UInt32 rc = HAPI.hllapi(ref f, d, ref l, ref p);
            len = l;
            return rc;

        }

        // Set Session Parameters (9)
        //NOATTRB/所有未知的值转换为空格
        //NOEAB/只传入数据不包含EABs(扩展属性字节)
        //NOXLATE/不转换EABs
        //DISPLAY/只将显示字符串存入缓冲区
        //NOEAD/不传送DBCS(双字节属性)的字符
        //这个函数没啥用到目前为止，增加的选项只会在填空栏增加字符到目前测试了N次不知道用处在哪里，最好是
        //通过天空栏长度一点一点加长度找到合适的长度
        public static UInt32 SetSessionParameters(out UInt32 len)
        {
            StringBuilder d = new StringBuilder(13);
            //d.Append("NOEXTEND_PS,NOEAD,NULLATTRB,NOATTRB,NODISPLAY,NOEAB");
            //d.Append("NOEXTEND_PS,NOSO,NOEAD,NODISPLAY,NULLATTRB");
            //d.Append("1");
            UInt32 f = (UInt32)Funcnum.FN_SET_SESSION_PARAMETERS;
            UInt32 l = 13;
            UInt32 p = 0;
            UInt32 rc = HAPI.hllapi(ref f, d, ref l, ref p);
            len = l;
            return rc;
        }


        //Search Presentation Space (6) 从搜索屏幕指定字符

        public static UInt32 SearchPS(string targetStr,UInt32 p)
        {
            StringBuilder d = new StringBuilder((int)targetStr.Length);
            d.Append(targetStr);
            UInt32 f = (UInt32)Funcnum.FN_SEARCH_PS;
            UInt32 l = (UInt32)targetStr.Length;
            UInt32 ps = p;
            UInt32 rc = HAPI.hllapi(ref f, d, ref l, ref ps);
            return rc;
        }


        //Reserve (11) 锁定键盘

        public static UInt32 LockKeyBoard()
        {

            StringBuilder d = new StringBuilder(0);
            UInt32 f = (UInt32)Funcnum.FN_LOCK_KB;
            UInt32 l = 0;
            UInt32 p = 0;
            UInt32 rc = HAPI.hllapi(ref f, d, ref l, ref p);
            return rc;

        }

        //Release (12) 释放键盘
        public static UInt32 ReleaseKeyBoard()
        {

            StringBuilder d = new StringBuilder(0);
            UInt32 f = (UInt32)Funcnum.FN_RELEASE_KB;
            UInt32 l = 0;
            UInt32 p = 0;
            UInt32 rc = HAPI.hllapi(ref f, d, ref l, ref p);
            return rc;

        }


        //Wait (4) 等待屏幕响应

        public static UInt32 WaitScreen()

        {
            StringBuilder d = new StringBuilder(0);
            UInt32 f = (UInt32)Funcnum.FN_WAIT_SCREEN;
            UInt32 l = 0;
            UInt32 p = 0;
            UInt32 rc = HAPI.hllapi(ref f, d, ref l, ref p);
            return rc;
        }

        public static UInt32 ResetSystem()

        {

            StringBuilder d = new StringBuilder(0);
            UInt32 f = (UInt32)Funcnum.FN_RESET_SYS;
            UInt32 l = 0;
            UInt32 p = 0;
            UInt32 rc = HAPI.hllapi(ref f, d, ref l, ref p);
            return rc;

        }

    }
}